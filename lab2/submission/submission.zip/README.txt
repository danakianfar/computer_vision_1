Assignment 2

Please find our code under code/
The report can be found in report.pdf

Students: 
Dana Kianfar - 11391014
Jose Gallego Posada - 11390689