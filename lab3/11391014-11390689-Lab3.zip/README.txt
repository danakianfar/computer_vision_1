Assignment 3

Please find our code under code/
The report can be found in report.pdf
The videos are under videos/

Students: 
Dana Kianfar - 11391014
Jose Gallego Posada - 11390689