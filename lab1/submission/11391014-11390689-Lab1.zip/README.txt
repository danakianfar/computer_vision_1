Assignment 1

Please find our code under code/
The report can be found in 11391014-11390689-Lab1.pdf

Students: 
Dana Kianfar - 11391014
Jose Gallego Posada - 11390689